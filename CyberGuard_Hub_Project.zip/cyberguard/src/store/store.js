import { configureStore } from '@reduxjs/toolkit'
import authReducer    from './slices/authSlice'
import newsReducer    from './slices/newsSlice'
import uiReducer      from './slices/uiSlice'
import quizReducer    from './slices/quizSlice'

export const store = configureStore({
  reducer: {
    auth:  authReducer,
    news:  newsReducer,
    ui:    uiReducer,
    quiz:  quizReducer,
  },
})
