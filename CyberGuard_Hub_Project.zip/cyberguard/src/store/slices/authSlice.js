import { createSlice } from '@reduxjs/toolkit'

// Simulated users – replace with Auth0 in production
const MOCK_USERS = [
  { id: 1, name: 'Admin User',   email: 'admin@cyber.dev',  password: 'admin123',  role: 'admin',  avatar: 'AU' },
  { id: 2, name: 'Jane Student', email: 'jane@cyber.dev',   password: 'jane123',   role: 'user',   avatar: 'JS' },
]

const stored = localStorage.getItem('cg_user')

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user:    stored ? JSON.parse(stored) : null,
    error:   null,
    loading: false,
  },
  reducers: {
    loginStart(state)         { state.loading = true; state.error = null },
    loginSuccess(state, { payload }) {
      state.loading = false
      state.user    = payload
      state.error   = null
      localStorage.setItem('cg_user', JSON.stringify(payload))
    },
    loginFail(state, { payload }) {
      state.loading = false
      state.error   = payload
    },
    logout(state) {
      state.user = null
      localStorage.removeItem('cg_user')
    },
  },
})

export const { loginStart, loginSuccess, loginFail, logout } = authSlice.actions

// Thunk
export const loginUser = (email, password) => (dispatch) => {
  dispatch(loginStart())
  setTimeout(() => {
    const found = MOCK_USERS.find(u => u.email === email && u.password === password)
    if (found) {
      const { password: _, ...safe } = found
      dispatch(loginSuccess(safe))
    } else {
      dispatch(loginFail('Invalid email or password'))
    }
  }, 800)
}

export default authSlice.reducer
