import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate, Link } from 'react-router-dom'
import { loginUser } from '../store/slices/authSlice'

export default function Login() {
  const dispatch  = useDispatch()
  const navigate  = useNavigate()
  const { loading, error, user } = useSelector(s => s.auth)
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')

  if (user) { navigate('/dashboard'); return null }

  const handleSubmit = (e) => {
    e.preventDefault()
    dispatch(loginUser(email, password))
    // Navigate after small delay (thunk is async)
    setTimeout(() => {
      const stored = localStorage.getItem('cg_user')
      if (stored) navigate('/dashboard')
    }, 1000)
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <div className="card max-w-md w-full space-y-6 glow-green">
        <div className="text-center">
          <div className="text-5xl mb-3">🔐</div>
          <h1 className="text-2xl font-bold text-cyber-green">Sign In</h1>
          <p className="text-cyber-muted text-sm mt-1">Welcome back to CyberGuard Hub</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm text-cyber-muted mb-1 block">Email</label>
            <input className="input" type="email" placeholder="you@example.com"
              value={email} onChange={e => setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="text-sm text-cyber-muted mb-1 block">Password</label>
            <input className="input" type="password" placeholder="••••••••"
              value={password} onChange={e => setPassword(e.target.value)} required />
          </div>

          {error && (
            <div className="bg-cyber-red/10 border border-cyber-red/30 text-cyber-red text-sm p-3 rounded-lg">
              {error}
            </div>
          )}

          <button type="submit" disabled={loading} className="btn-primary w-full py-2.5 text-center">
            {loading ? 'Signing in…' : 'Sign In'}
          </button>
        </form>

        {/* Demo credentials hint */}
        <div className="bg-cyber-mid rounded-lg p-4 text-xs text-cyber-muted space-y-1 font-mono">
          <p className="text-cyber-green font-semibold mb-1">Demo Accounts</p>
          <p>👤 admin@cyber.dev / admin123 &nbsp;<span className="badge bg-cyber-red/20 text-cyber-red">Admin</span></p>
          <p>👤 jane@cyber.dev  / jane123 &nbsp;&nbsp;<span className="badge bg-cyber-blue/20 text-cyber-blue">User</span></p>
        </div>
      </div>
    </div>
  )
}
