import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'

const STATS = [
  { icon: '🦠', value: '6.06B',  label: 'Malware attacks in 2023' },
  { icon: '🎣', value: '3.4B',   label: 'Phishing emails per day'  },
  { icon: '💰', value: '$4.45M', label: 'Avg. data breach cost'    },
  { icon: '⏱',  value: '39 sec', label: 'A new attack every...'   },
]

const TIPS = [
  { icon: '🔑', title: 'Use a Password Manager',    body: 'Never reuse passwords. Let a manager generate unique, complex ones for every site.' },
  { icon: '📲', title: 'Enable Two-Factor Auth',    body: 'Even if your password leaks, 2FA blocks attackers from accessing your account.' },
  { icon: '🔄', title: 'Keep Software Updated',     body: 'Most breaches exploit known vulnerabilities. Updates patch these holes.' },
  { icon: '🎣', title: 'Think Before You Click',    body: 'Hover over links before clicking. Check the sender\'s actual email domain.' },
  { icon: '🛡', title: 'Back Up Your Data',         body: 'The 3-2-1 rule: 3 copies, 2 media types, 1 offsite backup.' },
  { icon: '📡', title: 'Use a VPN on Public Wi-Fi', body: 'Public networks can be monitored. A VPN encrypts your traffic end-to-end.' },
]

export default function Home() {
  const { user } = useSelector(s => s.auth)

  return (
    <div className="max-w-5xl mx-auto space-y-10">
      {/* Hero */}
      <section className="text-center py-12 space-y-5">
        <div className="text-7xl">🛡</div>
        <h1 className="text-4xl md:text-5xl font-bold">
          Stay <span className="text-cyber-green">Cyber</span> Safe
        </h1>
        <p className="text-cyber-muted max-w-xl mx-auto text-lg leading-relaxed">
          CyberGuard Hub is your interactive platform for cybersecurity awareness —
          real-time threat news, quizzes, tools, and your personal security dashboard.
        </p>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <Link to="/news"  className="btn-primary">📰 Threat News</Link>
          <Link to="/quiz"  className="btn-ghost">🧠 Take the Quiz</Link>
          {!user && <Link to="/login" className="btn-ghost">🔐 Login</Link>}
        </div>
      </section>

      {/* Stats */}
      <section>
        <h2 className="text-xl font-bold text-cyber-text mb-4">⚡ Cyber Threat Landscape</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {STATS.map(s => (
            <div key={s.label} className="card text-center space-y-1 glow-green">
              <div className="text-3xl">{s.icon}</div>
              <div className="text-2xl font-bold text-cyber-green font-mono">{s.value}</div>
              <div className="text-cyber-muted text-xs">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Tips */}
      <section>
        <h2 className="text-xl font-bold text-cyber-text mb-4">💡 Security Quick Tips</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {TIPS.map(t => (
            <div key={t.title} className="card hover:border-cyber-green/50 transition-colors group">
              <div className="text-3xl mb-2">{t.icon}</div>
              <h3 className="font-semibold text-cyber-text group-hover:text-cyber-green transition-colors mb-1">{t.title}</h3>
              <p className="text-cyber-muted text-sm leading-relaxed">{t.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="card text-center border-cyber-green/30 glow-green py-8 space-y-3">
        <h2 className="text-2xl font-bold">Test Your Security Knowledge</h2>
        <p className="text-cyber-muted">Take our 8-question cybersecurity quiz and find out how safe you really are.</p>
        <Link to="/quiz" className="btn-primary inline-block">Start Quiz →</Link>
      </section>
    </div>
  )
}
