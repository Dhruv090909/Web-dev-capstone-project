import { useState } from 'react'
import { useSelector } from 'react-redux'

const MOCK_USERS = [
  { id: 1, name: 'Admin User',   email: 'admin@cyber.dev', role: 'admin', quizzes: 3, score: 87 },
  { id: 2, name: 'Jane Student', email: 'jane@cyber.dev',  role: 'user',  quizzes: 5, score: 72 },
  { id: 3, name: 'Guest Demo',   email: 'guest@cyber.dev', role: 'user',  quizzes: 1, score: 50 },
]

export default function Admin() {
  const { user }       = useSelector(s => s.auth)
  const { history }    = useSelector(s => s.quiz)
  const bookmarkCount  = useSelector(s => s.news.bookmarks.length)
  const [search, setSearch] = useState('')

  const filtered = MOCK_USERS.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-bold">⚙️ Admin Panel</h1>
        <span className="badge bg-cyber-red/20 text-cyber-red">RESTRICTED</span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: '👥', label: 'Total Users',    value: MOCK_USERS.length },
          { icon: '🧠', label: 'Total Quizzes',  value: history.length },
          { icon: '🔖', label: 'Bookmarks',      value: bookmarkCount },
          { icon: '🛡', label: 'Active Sessions', value: 1 },
        ].map(s => (
          <div key={s.label} className="card text-center">
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold text-cyber-green font-mono">{s.value}</div>
            <div className="text-cyber-muted text-xs">{s.label}</div>
          </div>
        ))}
      </div>

      {/* User management */}
      <div className="card space-y-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-semibold text-cyber-text">👥 User Management</h2>
          <input className="input w-48 text-xs" placeholder="Search users…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-cyber-muted text-xs border-b border-cyber-border">
                <th className="text-left pb-2">User</th>
                <th className="text-left pb-2">Role</th>
                <th className="text-left pb-2">Quizzes</th>
                <th className="text-left pb-2">Avg Score</th>
                <th className="text-left pb-2">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cyber-border">
              {filtered.map(u => (
                <tr key={u.id} className="hover:bg-cyber-mid transition-colors">
                  <td className="py-3">
                    <div>
                      <p className="font-medium text-cyber-text">{u.name}</p>
                      <p className="text-cyber-muted text-xs">{u.email}</p>
                    </div>
                  </td>
                  <td className="py-3">
                    <span className={`badge ${u.role === 'admin' ? 'bg-cyber-red/20 text-cyber-red' : 'bg-cyber-blue/20 text-cyber-blue'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3 text-cyber-muted">{u.quizzes}</td>
                  <td className="py-3">
                    <span className={`font-mono font-bold ${u.score >= 70 ? 'text-cyber-green' : 'text-cyber-red'}`}>
                      {u.score}%
                    </span>
                  </td>
                  <td className="py-3">
                    <button className="text-xs text-cyber-muted hover:text-cyber-red transition-colors"
                      disabled={u.email === user?.email}>
                      {u.email === user?.email ? 'You' : 'Revoke'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* System log */}
      <div className="card space-y-3">
        <h2 className="font-semibold text-cyber-text">📋 System Log</h2>
        <div className="font-mono text-xs text-cyber-muted space-y-1 bg-cyber-dark p-4 rounded-lg">
          <p><span className="text-cyber-green">[INFO]</span> CyberGuard Hub v1.0 started</p>
          <p><span className="text-cyber-green">[INFO]</span> Admin session opened: {user?.email}</p>
          <p><span className="text-cyber-blue">[DEBUG]</span> Redux store initialised: auth, news, quiz, ui</p>
          <p><span className="text-yellow-400">[WARN]</span> NewsData.io API key not set — running in demo mode</p>
          <p><span className="text-cyber-green">[INFO]</span> Error boundaries active on: App, Dashboard widgets</p>
        </div>
      </div>
    </div>
  )
}
