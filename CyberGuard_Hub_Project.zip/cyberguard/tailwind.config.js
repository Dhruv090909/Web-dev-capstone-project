/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        cyber: {
          green:  '#00D4AA',
          red:    '#FF6B6B',
          blue:   '#58A6FF',
          dark:   '#0D1117',
          mid:    '#161B22',
          card:   '#21262D',
          border: '#30363D',
          muted:  '#8B949E',
          text:   '#C9D1D9',
        },
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
    },
  },
  plugins: [],
}
