import { createSlice } from '@reduxjs/toolkit'

const uiSlice = createSlice({
  name: 'ui',
  initialState: {
    darkMode:      localStorage.getItem('cg_dark') !== 'false',
    sidebarOpen:   true,
    toast:         null,   // { message, type: 'success'|'error'|'info' }
  },
  reducers: {
    toggleDark(state) {
      state.darkMode = !state.darkMode
      localStorage.setItem('cg_dark', state.darkMode)
    },
    toggleSidebar(state) { state.sidebarOpen = !state.sidebarOpen },
    showToast(state, { payload }) { state.toast = payload },
    hideToast(state)               { state.toast = null },
  },
})

export const { toggleDark, toggleSidebar, showToast, hideToast } = uiSlice.actions
export default uiSlice.reducer
