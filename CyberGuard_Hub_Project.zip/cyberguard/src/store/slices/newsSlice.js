import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

// ──────────────────────────────────────────────────────────────────────────────
// Fallback mock articles (shown when API key is missing / quota exceeded)
// ──────────────────────────────────────────────────────────────────────────────
const MOCK_ARTICLES = Array.from({ length: 24 }, (_, i) => ({
  article_id:   `mock_${i}`,
  title:        [
    'New Ransomware Gang Targets Healthcare Sector Worldwide',
    'Critical Zero-Day Found in Popular VPN Software',
    'How to Spot a Phishing Email in 2026',
    'Government Agencies Warn of Surge in Supply Chain Attacks',
    'AI-Powered Malware Evades Traditional Antivirus Tools',
    'Best Practices for Password Management in 2026',
    'Social Engineering: The Biggest Threat You Can\'t Patch',
    'Dark Web Marketplace Taken Down in Global Operation',
  ][i % 8],
  description:  'Cybersecurity researchers have uncovered a sophisticated campaign affecting organisations globally. Experts recommend immediate patching and employee awareness training.',
  link:         'https://example.com/article',
  image_url:    null,
  pubDate:      new Date(Date.now() - i * 3_600_000).toISOString(),
  source_name:  ['The Hacker News','Krebs on Security','Dark Reading','BleepingComputer'][i % 4],
  category:     [['ransomware'],['vulnerability'],['phishing'],['cybersecurity']][i % 4],
  sentiment:    ['negative','neutral','positive'][i % 3],
}))

// ──────────────────────────────────────────────────────────────────────────────
// Async thunk – fetches from NewsData.io; falls back to mock on error
// ──────────────────────────────────────────────────────────────────────────────
export const fetchNews = createAsyncThunk(
  'news/fetchNews',
  async ({ query = 'cybersecurity', page = 1 }, { rejectWithValue }) => {
    const API_KEY = import.meta.env.VITE_NEWS_API_KEY
    if (!API_KEY) return { results: MOCK_ARTICLES, nextPage: null, mock: true }

    try {
      const res = await axios.get('https://newsdata.io/api/1/news', {
        params: {
          apikey:   API_KEY,
          q:        query,
          language: 'en',
          category: 'technology',
          page,
        },
      })
      return { results: res.data.results || [], nextPage: res.data.nextPage || null, mock: false }
    } catch (err) {
      // Quota / network error → graceful fallback
      return { results: MOCK_ARTICLES, nextPage: null, mock: true }
    }
  }
)

const newsSlice = createSlice({
  name: 'news',
  initialState: {
    articles:    [],
    status:      'idle',   // 'idle' | 'loading' | 'succeeded' | 'failed'
    error:       null,
    nextPage:    null,
    isMock:      false,
    search:      '',
    filter:      'all',    // 'all' | 'ransomware' | 'phishing' | 'vulnerability' | 'cybersecurity'
    sort:        'newest', // 'newest' | 'oldest'
    bookmarks:   JSON.parse(localStorage.getItem('cg_bookmarks') || '[]'),
  },
  reducers: {
    setSearch(state, { payload })   { state.search = payload },
    setFilter(state, { payload })   { state.filter = payload },
    setSort(state, { payload })     { state.sort   = payload },
    clearArticles(state)            { state.articles = []; state.nextPage = null },
    toggleBookmark(state, { payload }) {
      const exists = state.bookmarks.find(b => b.article_id === payload.article_id)
      if (exists) state.bookmarks = state.bookmarks.filter(b => b.article_id !== payload.article_id)
      else        state.bookmarks.push(payload)
      localStorage.setItem('cg_bookmarks', JSON.stringify(state.bookmarks))
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchNews.pending,   (state) => { state.status = 'loading'; state.error = null })
      .addCase(fetchNews.fulfilled, (state, { payload }) => {
        state.status   = 'succeeded'
        state.isMock   = payload.mock
        state.nextPage = payload.nextPage
        // Append for infinite scroll
        const ids = new Set(state.articles.map(a => a.article_id))
        state.articles.push(...payload.results.filter(a => !ids.has(a.article_id)))
      })
      .addCase(fetchNews.rejected,  (state, { error }) => {
        state.status = 'failed'
        state.error  = error.message
      })
  },
})

export const { setSearch, setFilter, setSort, clearArticles, toggleBookmark } = newsSlice.actions

// ── Selectors ─────────────────────────────────────────────────────────────────
export const selectFilteredArticles = (state) => {
  let list = [...state.news.articles]
  const { search, filter, sort } = state.news

  if (search)       list = list.filter(a => a.title?.toLowerCase().includes(search.toLowerCase()))
  if (filter !== 'all') list = list.filter(a => a.category?.some(c => c.toLowerCase().includes(filter)))
  if (sort === 'oldest') list.sort((a, b) => new Date(a.pubDate) - new Date(b.pubDate))
  else                   list.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate))

  return list
}

export default newsSlice.reducer
