# 🛡 CyberGuard Hub

An interactive **Cybersecurity Awareness Platform** built with React (Vite), Redux Toolkit, React Router, Tailwind CSS, and Recharts.

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Add your API key (optional — works in demo mode without it)
cp .env.example .env
# Edit .env and add your free NewsData.io key

# 3. Start dev server
npm run dev

# 4. Open http://localhost:5173
```

## 🔐 Demo Login Credentials

| Email               | Password   | Role  |
|---------------------|------------|-------|
| admin@cyber.dev     | admin123   | Admin |
| jane@cyber.dev      | jane123    | User  |

## 🗂 Project Structure

```
src/
├── store/slices/      # Redux slices (auth, news, quiz, ui)
├── components/        # Navbar, Sidebar, ErrorBoundary, Toast
├── pages/             # Home, News, Quiz, Tools, Dashboard, Admin, Bookmarks
├── router/            # AppRouter, ProtectedRoute
├── hooks/             # useDebounce, useInfiniteScroll
└── utils/             # passwordStrength
```

## ✅ Features Implemented

| Feature                        | Details                                       |
|--------------------------------|-----------------------------------------------|
| Authentication + RBAC          | Mock auth, admin/user roles, protected routes |
| Infinite scrolling             | News feed via IntersectionObserver            |
| Search + Filter + Sort         | Debounced search, category filter, date sort  |
| Dark mode toggle               | Persisted in localStorage                     |
| Dashboard with charts          | Line, Bar, and Radar charts via Recharts      |
| Debounced API calls            | `useDebounce` hook — 400 ms delay             |
| Error boundary                 | Two-level: App + component level              |
| Memoisation                    | `useMemo` on filtered articles & chart data   |
| Multi-step quiz with validation| 8-question quiz, must answer to advance       |
| CRUD operations                | Bookmark (create/delete), profile (update)    |

## 🌐 Deployment (Vercel)

```bash
npm run build
# Push to GitHub, connect repo to Vercel — done.
```

Add `VITE_NEWS_API_KEY` to Vercel project environment variables.

## 📡 API

- **NewsData.io** — Free tier, 200 requests/day. Get key at https://newsdata.io
- Falls back to built-in mock articles if key is missing.
