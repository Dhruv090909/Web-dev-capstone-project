import { createSlice } from '@reduxjs/toolkit'

const QUESTIONS = [
  {
    id: 1, category: 'Phishing',
    question: 'Which of the following is the BEST way to verify a suspicious email asking for your login credentials?',
    options: [
      'Click the link and check if the website looks real',
      'Reply to the email asking if it is legitimate',
      'Contact the organisation directly using their official website or phone number',
      'Forward it to a friend for a second opinion',
    ],
    answer: 2,
    explanation: 'Always verify suspicious requests through official, independently confirmed channels — never trust links or numbers provided in the email itself.',
  },
  {
    id: 2, category: 'Passwords',
    question: 'Which password is MOST secure?',
    options: ['Password123!', 'p@ssw0rd', 'Tr0ub4dor&3horse', 'qwerty2026'],
    answer: 2,
    explanation: 'A long passphrase (4+ random words) is harder to crack than short complex passwords. Length matters more than complexity alone.',
  },
  {
    id: 3, category: 'Malware',
    question: 'You receive an unexpected USB drive in the mail with a note saying "Your Salary Report". What should you do?',
    options: [
      'Plug it in on an old computer to check',
      'Hand it to your IT/security team without plugging it in',
      'Plug it in but do not open any files',
      'Format it and reuse it',
    ],
    answer: 1,
    explanation: 'Baiting attacks use physical media left in public or mailed to targets. Never plug in unknown USB devices — report them to IT security.',
  },
  {
    id: 4, category: 'Social Engineering',
    question: 'An urgent call from "Microsoft Support" says your PC has a virus and asks for remote access. You should:',
    options: [
      'Grant access so they can fix it quickly',
      'Ask for their employee ID and call back',
      'Hang up immediately — legitimate companies do not make unsolicited support calls',
      'Run a scan first, then let them in',
    ],
    answer: 2,
    explanation: 'Tech-support scams are extremely common. Microsoft, Google, and Apple never make unsolicited calls about viruses. Hang up immediately.',
  },
  {
    id: 5, category: 'Network Security',
    question: 'What is the safest way to use public Wi-Fi for sensitive tasks like banking?',
    options: [
      'Use incognito mode',
      'Make sure the website has HTTPS',
      'Use a trusted VPN',
      'Avoid public Wi-Fi entirely and use mobile data instead',
    ],
    answer: 2,
    explanation: 'A VPN encrypts your traffic end-to-end even on untrusted networks. HTTPS alone does not protect against man-in-the-middle attacks on public Wi-Fi.',
  },
  {
    id: 6, category: 'Ransomware',
    question: 'Your company\'s files are suddenly encrypted and a ransom demand appears. The BEST first response is:',
    options: [
      'Pay the ransom immediately to restore access',
      'Disconnect affected systems from the network and contact your IT security team',
      'Try to decrypt the files yourself',
      'Restart the computer and hope it clears',
    ],
    answer: 1,
    explanation: 'Isolating infected systems prevents ransomware from spreading across the network. Never pay — it funds criminals and does not guarantee recovery.',
  },
  {
    id: 7, category: '2FA',
    question: 'Which form of two-factor authentication is MOST secure?',
    options: [
      'SMS one-time passwords',
      'Email verification codes',
      'Hardware security key (e.g. YubiKey)',
      'Security questions',
    ],
    answer: 2,
    explanation: 'Hardware keys are phishing-resistant because they verify the actual website domain. SMS and email codes can be intercepted or SIM-swapped.',
  },
  {
    id: 8, category: 'Data Privacy',
    question: 'A free mobile app requests access to your contacts, camera, microphone, and location. You should:',
    options: [
      'Accept all — it is free so you are the product',
      'Deny all permissions and delete the app',
      'Grant only the permissions strictly necessary for the app to function',
      'Accept and review later',
    ],
    answer: 2,
    explanation: 'Principle of least privilege applies to apps too. Only grant permissions the app genuinely needs. Revoke others in your phone settings.',
  },
]

const stored = JSON.parse(localStorage.getItem('cg_quiz_history') || '[]')

const quizSlice = createSlice({
  name: 'quiz',
  initialState: {
    questions:    QUESTIONS,
    current:      0,
    answers:      {},      // { [questionId]: selectedIndex }
    submitted:    false,
    history:      stored,  // [{ date, score, total }]
    started:      false,
  },
  reducers: {
    startQuiz(state)  { state.started = true; state.current = 0; state.answers = {}; state.submitted = false },
    answerQuestion(state, { payload: { id, index } }) { state.answers[id] = index },
    nextQuestion(state) { if (state.current < state.questions.length - 1) state.current++ },
    prevQuestion(state) { if (state.current > 0) state.current-- },
    submitQuiz(state) {
      state.submitted = true
      const score = state.questions.reduce((acc, q) => acc + (state.answers[q.id] === q.answer ? 1 : 0), 0)
      const entry = { date: new Date().toISOString(), score, total: state.questions.length }
      state.history.unshift(entry)
      if (state.history.length > 10) state.history.pop()
      localStorage.setItem('cg_quiz_history', JSON.stringify(state.history))
    },
    resetQuiz(state) { state.started = false; state.submitted = false; state.answers = {}; state.current = 0 },
  },
})

export const { startQuiz, answerQuestion, nextQuestion, prevQuestion, submitQuiz, resetQuiz } = quizSlice.actions

export const selectScore = (state) => {
  const { questions, answers } = state.quiz
  return questions.reduce((acc, q) => acc + (answers[q.id] === q.answer ? 1 : 0), 0)
}

export default quizSlice.reducer
