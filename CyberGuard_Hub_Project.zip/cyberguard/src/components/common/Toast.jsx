import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { hideToast } from '../../store/slices/uiSlice'

export function Toast() {
  const dispatch = useDispatch()
  const toast    = useSelector(s => s.ui.toast)

  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => dispatch(hideToast()), 3000)
    return () => clearTimeout(t)
  }, [toast, dispatch])

  if (!toast) return null

  const colors = {
    success: 'border-cyber-green text-cyber-green',
    error:   'border-cyber-red   text-cyber-red',
    info:    'border-cyber-blue  text-cyber-blue',
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 card border-l-4 ${colors[toast.type] || colors.info} shadow-lg max-w-sm animate-bounce-in`}>
      <p className="text-sm font-medium">{toast.message}</p>
    </div>
  )
}
