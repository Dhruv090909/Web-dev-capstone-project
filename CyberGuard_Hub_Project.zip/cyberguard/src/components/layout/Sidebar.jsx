import { NavLink } from 'react-router-dom'
import { useSelector } from 'react-redux'

const links = [
  { to: '/',          icon: '🏠', label: 'Home'       },
  { to: '/news',      icon: '📰', label: 'Threat News' },
  { to: '/quiz',      icon: '🧠', label: 'Quiz'        },
  { to: '/tools',     icon: '🔧', label: 'Tools'       },
  { to: '/dashboard', icon: '📊', label: 'Dashboard'   },
  { to: '/bookmarks', icon: '🔖', label: 'Bookmarks'   },
]

const adminLinks = [
  { to: '/admin', icon: '⚙️', label: 'Admin Panel' },
]

export function Sidebar() {
  const { sidebarOpen } = useSelector(s => s.ui)
  const { user }        = useSelector(s => s.auth)

  const navCls = ({ isActive }) =>
    `flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm transition-all duration-200 ${
      isActive
        ? 'bg-cyber-green/10 text-cyber-green border border-cyber-green/30'
        : 'text-cyber-muted hover:text-cyber-text hover:bg-cyber-card'
    }`

  if (!sidebarOpen) return null

  return (
    <aside className="w-52 flex-shrink-0 bg-cyber-mid border-r border-cyber-border min-h-screen py-4 px-2 hidden md:flex flex-col gap-1">
      {links.map(l => (
        <NavLink key={l.to} to={l.to} end={l.to === '/'} className={navCls}>
          <span>{l.icon}</span>
          <span>{l.label}</span>
        </NavLink>
      ))}

      {user?.role === 'admin' && (
        <>
          <div className="border-t border-cyber-border my-2" />
          {adminLinks.map(l => (
            <NavLink key={l.to} to={l.to} className={navCls}>
              <span>{l.icon}</span>
              <span>{l.label}</span>
            </NavLink>
          ))}
        </>
      )}

      <div className="mt-auto px-4 pt-4 border-t border-cyber-border">
        <p className="text-cyber-muted text-xs">CyberGuard Hub v1.0</p>
      </div>
    </aside>
  )
}
