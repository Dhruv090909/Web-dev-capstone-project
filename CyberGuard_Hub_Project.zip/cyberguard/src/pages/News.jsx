import { useEffect, useCallback, useMemo } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchNews, setSearch, setFilter, setSort, clearArticles, toggleBookmark, selectFilteredArticles } from '../store/slices/newsSlice'
import { useDebounce }         from '../hooks/useDebounce'
import { useInfiniteScroll }   from '../hooks/useInfiniteScroll'

const CATEGORIES = ['all', 'ransomware', 'phishing', 'vulnerability', 'cybersecurity']

function ArticleCard({ article }) {
  const dispatch   = useDispatch()
  const bookmarks  = useSelector(s => s.news.bookmarks)
  const isBookmarked = bookmarks.some(b => b.article_id === article.article_id)

  return (
    <div className="card hover:border-cyber-green/40 transition-all duration-200 flex flex-col gap-2">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1">
          <a href={article.link} target="_blank" rel="noopener noreferrer"
            className="font-semibold text-cyber-text hover:text-cyber-green transition-colors line-clamp-2 leading-snug">
            {article.title}
          </a>
          <p className="text-cyber-muted text-xs mt-1">{article.source_name} · {new Date(article.pubDate).toLocaleDateString()}</p>
        </div>
        <button
          onClick={() => dispatch(toggleBookmark(article))}
          className={`text-lg transition-colors flex-shrink-0 ${isBookmarked ? 'text-cyber-green' : 'text-cyber-muted hover:text-cyber-green'}`}
          title={isBookmarked ? 'Remove bookmark' : 'Bookmark'}
        >🔖</button>
      </div>

      {article.description && (
        <p className="text-cyber-muted text-sm line-clamp-2 leading-relaxed">{article.description}</p>
      )}

      <div className="flex flex-wrap gap-1 mt-1">
        {article.category?.map(c => (
          <span key={c} className="badge bg-cyber-green/10 text-cyber-green">{c}</span>
        ))}
        {article.sentiment && (
          <span className={`badge ${
            article.sentiment === 'negative' ? 'bg-cyber-red/10 text-cyber-red' :
            article.sentiment === 'positive' ? 'bg-cyber-green/10 text-cyber-green' :
            'bg-cyber-border text-cyber-muted'
          }`}>{article.sentiment}</span>
        )}
      </div>
    </div>
  )
}

export default function News() {
  const dispatch  = useDispatch()
  const { status, nextPage, isMock, search, filter, sort } = useSelector(s => s.news)
  const articles  = useSelector(selectFilteredArticles)
  const debouncedSearch = useDebounce(search, 400)

  // Initial fetch
  useEffect(() => {
    dispatch(clearArticles())
    dispatch(fetchNews({ query: 'cybersecurity ' + debouncedSearch }))
  }, [debouncedSearch, dispatch])

  const loadMore = useCallback(() => {
    if (status !== 'loading' && nextPage) {
      dispatch(fetchNews({ query: 'cybersecurity ' + debouncedSearch, page: nextPage }))
    }
  }, [status, nextPage, debouncedSearch, dispatch])

  const sentinelRef = useInfiniteScroll(loadMore, !!nextPage && status !== 'loading')

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-2xl font-bold">📰 Threat News</h1>
        {isMock && (
          <span className="badge bg-yellow-500/20 text-yellow-400">
            Demo mode — add VITE_NEWS_API_KEY for live news
          </span>
        )}
      </div>

      {/* Controls */}
      <div className="card space-y-3">
        {/* Search */}
        <input
          className="input"
          placeholder="🔍 Search articles…"
          value={search}
          onChange={e => dispatch(setSearch(e.target.value))}
        />
        <div className="flex flex-wrap gap-2 items-center">
          {/* Filter */}
          <div className="flex gap-1 flex-wrap">
            {CATEGORIES.map(c => (
              <button key={c}
                onClick={() => dispatch(setFilter(c))}
                className={`badge transition-all ${filter === c ? 'bg-cyber-green text-cyber-dark' : 'bg-cyber-border text-cyber-muted hover:text-cyber-text'}`}>
                {c}
              </button>
            ))}
          </div>
          {/* Sort */}
          <select
            value={sort}
            onChange={e => dispatch(setSort(e.target.value))}
            className="input w-auto text-xs"
          >
            <option value="newest">Newest first</option>
            <option value="oldest">Oldest first</option>
          </select>
        </div>
      </div>

      {/* Article Grid */}
      <div className="grid gap-4">
        {articles.map(a => <ArticleCard key={a.article_id} article={a} />)}
      </div>

      {/* States */}
      {status === 'loading' && (
        <div className="text-center py-8 text-cyber-muted font-mono text-sm animate-pulse">⟳ Fetching threat data…</div>
      )}
      {status === 'failed' && (
        <div className="card border-cyber-red/30 text-cyber-red text-center">Failed to load news. Using cached data.</div>
      )}
      {articles.length === 0 && status === 'succeeded' && (
        <div className="text-center py-8 text-cyber-muted">No articles match your search.</div>
      )}

      {/* Infinite scroll sentinel */}
      <div ref={sentinelRef} className="h-4" />
    </div>
  )
}
