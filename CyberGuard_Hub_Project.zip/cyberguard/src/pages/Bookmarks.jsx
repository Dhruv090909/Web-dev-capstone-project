import { useSelector, useDispatch } from 'react-redux'
import { toggleBookmark } from '../store/slices/newsSlice'
import { Link } from 'react-router-dom'

export default function Bookmarks() {
  const dispatch  = useDispatch()
  const bookmarks = useSelector(s => s.news.bookmarks)

  if (bookmarks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center gap-4">
        <div className="text-5xl">🔖</div>
        <h2 className="text-xl font-bold text-cyber-text">No bookmarks yet</h2>
        <p className="text-cyber-muted">Save articles from the Threat News page.</p>
        <Link to="/news" className="btn-primary">Browse News →</Link>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">🔖 Saved Articles</h1>
        <span className="badge bg-cyber-green/10 text-cyber-green">{bookmarks.length} saved</span>
      </div>

      <div className="grid gap-4">
        {bookmarks.map(a => (
          <div key={a.article_id} className="card hover:border-cyber-green/40 transition-colors flex flex-col gap-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <a href={a.link} target="_blank" rel="noopener noreferrer"
                  className="font-semibold hover:text-cyber-green transition-colors">
                  {a.title}
                </a>
                <p className="text-cyber-muted text-xs mt-1">{a.source_name} · {new Date(a.pubDate).toLocaleDateString()}</p>
              </div>
              <button onClick={() => dispatch(toggleBookmark(a))}
                className="text-cyber-red hover:text-cyber-red/70 text-sm flex-shrink-0" title="Remove">✕</button>
            </div>
            {a.description && <p className="text-cyber-muted text-sm line-clamp-2">{a.description}</p>}
          </div>
        ))}
      </div>
    </div>
  )
}
