import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { toggleDark, toggleSidebar } from '../../store/slices/uiSlice'
import { logout } from '../../store/slices/authSlice'

export function Navbar() {
  const dispatch  = useDispatch()
  const navigate  = useNavigate()
  const { user }  = useSelector(s => s.auth)
  const { darkMode } = useSelector(s => s.ui)

  const handleLogout = () => { dispatch(logout()); navigate('/login') }

  return (
    <nav className="sticky top-0 z-40 bg-cyber-mid border-b border-cyber-border px-4 py-3 flex items-center justify-between">
      {/* Left */}
      <div className="flex items-center gap-3">
        <button onClick={() => dispatch(toggleSidebar())} className="text-cyber-muted hover:text-cyber-text p-1">
          ☰
        </button>
        <Link to="/" className="flex items-center gap-2">
          <span className="text-cyber-green font-mono font-bold text-lg">🛡 CyberGuard</span>
        </Link>
      </div>

      {/* Right */}
      <div className="flex items-center gap-3">
        {/* Dark mode toggle */}
        <button
          onClick={() => dispatch(toggleDark())}
          className="btn-ghost text-lg px-2 py-1"
          title="Toggle dark mode"
        >
          {darkMode ? '☀️' : '🌙'}
        </button>

        {user ? (
          <div className="flex items-center gap-3">
            {user.role === 'admin' && (
              <Link to="/admin" className="badge bg-cyber-red/20 text-cyber-red">ADMIN</Link>
            )}
            <span className="text-sm text-cyber-muted hidden sm:block">{user.name}</span>
            <div className="w-8 h-8 rounded-full bg-cyber-green text-cyber-dark flex items-center justify-center font-bold text-xs">
              {user.avatar}
            </div>
            <button onClick={handleLogout} className="btn-ghost text-xs">Logout</button>
          </div>
        ) : (
          <Link to="/login" className="btn-primary">Login</Link>
        )}
      </div>
    </nav>
  )
}
