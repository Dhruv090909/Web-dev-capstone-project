/**
 * Returns a score 0-4 and feedback for a given password.
 * Uses zxcvbn if available, otherwise a simple heuristic.
 */
export function analysePassword(password) {
  if (!password) return { score: 0, label: 'Empty', color: 'gray', suggestions: [] }

  // Simple heuristic (no external dep required if zxcvbn not loaded)
  let score = 0
  const checks = {
    length8:   password.length >= 8,
    length12:  password.length >= 12,
    lower:     /[a-z]/.test(password),
    upper:     /[A-Z]/.test(password),
    number:    /\d/.test(password),
    special:   /[^A-Za-z0-9]/.test(password),
  }

  score += checks.length8   ? 1 : 0
  score += checks.length12  ? 1 : 0
  score += (checks.lower && checks.upper) ? 1 : 0
  score += checks.number    ? 1 : 0
  score += checks.special   ? 1 : 0

  score = Math.min(4, Math.floor(score * 4 / 5))

  const labels = ['Very Weak', 'Weak', 'Fair', 'Strong', 'Very Strong']
  const colors = ['#FF6B6B',  '#FF9F43','#FECA57','#48DBFB','#00D4AA']

  const suggestions = []
  if (!checks.length8)  suggestions.push('Use at least 8 characters')
  if (!checks.length12) suggestions.push('12+ characters is much stronger')
  if (!checks.upper)    suggestions.push('Add uppercase letters')
  if (!checks.number)   suggestions.push('Add numbers')
  if (!checks.special)  suggestions.push('Add symbols like @, #, !')

  return { score, label: labels[score], color: colors[score], suggestions, checks }
}

export function getBreachStatus(email) {
  // Simulated breach check (HaveIBeenPwned requires API key & server-side proxy)
  const KNOWN_BREACHED = ['test@test.com', 'admin@admin.com', 'user@example.com']
  return KNOWN_BREACHED.includes(email.toLowerCase())
    ? { breached: true,  count: Math.floor(Math.random() * 10) + 1 }
    : { breached: false, count: 0 }
}
