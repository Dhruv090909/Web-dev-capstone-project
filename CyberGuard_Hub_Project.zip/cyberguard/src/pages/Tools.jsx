import { useState, useMemo } from 'react'
import { analysePassword, getBreachStatus } from '../utils/passwordStrength'

function PasswordChecker() {
  const [pw, setPw]             = useState('')
  const [show, setShow]         = useState(false)
  const result = useMemo(() => analysePassword(pw), [pw])

  return (
    <div className="card space-y-4">
      <h2 className="font-bold text-cyber-text text-lg">🔑 Password Strength Checker</h2>

      <div className="relative">
        <input
          className="input pr-10"
          type={show ? 'text' : 'password'}
          placeholder="Type a password to analyse…"
          value={pw}
          onChange={e => setPw(e.target.value)}
        />
        <button
          className="absolute right-3 top-1/2 -translate-y-1/2 text-cyber-muted"
          onClick={() => setShow(v => !v)}
        >{show ? '🙈' : '👁'}</button>
      </div>

      {pw && (
        <div className="space-y-3">
          {/* Strength bar */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-cyber-muted">Strength</span>
              <span className="text-xs font-bold font-mono" style={{ color: result.color }}>{result.label}</span>
            </div>
            <div className="w-full bg-cyber-border rounded-full h-2">
              <div className="h-2 rounded-full transition-all duration-500"
                style={{ width: `${(result.score / 4) * 100}%`, backgroundColor: result.color }} />
            </div>
          </div>

          {/* Checks grid */}
          {result.checks && (
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              {[
                ['length8',  '8+ characters'],
                ['length12', '12+ characters'],
                ['lower',    'Lowercase'],
                ['upper',    'Uppercase'],
                ['number',   'Numbers'],
                ['special',  'Symbols'],
              ].map(([key, label]) => (
                <div key={key} className={`flex items-center gap-1.5 ${result.checks[key] ? 'text-cyber-green' : 'text-cyber-muted'}`}>
                  <span>{result.checks[key] ? '✓' : '✗'}</span>
                  <span>{label}</span>
                </div>
              ))}
            </div>
          )}

          {/* Suggestions */}
          {result.suggestions.length > 0 && (
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 space-y-1">
              <p className="text-yellow-400 text-xs font-semibold">Suggestions</p>
              {result.suggestions.map(s => <p key={s} className="text-yellow-300 text-xs">• {s}</p>)}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function BreachChecker() {
  const [email, setEmail] = useState('')
  const [result, setResult] = useState(null)
  const [checked, setChecked] = useState(false)

  const check = () => {
    if (!email) return
    const r = getBreachStatus(email)
    setResult(r)
    setChecked(true)
  }

  return (
    <div className="card space-y-4">
      <h2 className="font-bold text-cyber-text text-lg">🚨 Email Breach Checker</h2>
      <p className="text-cyber-muted text-sm">Check if your email has appeared in known data breaches (simulated for demo).</p>

      <div className="flex gap-2">
        <input className="input" type="email" placeholder="your@email.com"
          value={email} onChange={e => { setEmail(e.target.value); setChecked(false) }} />
        <button className="btn-primary flex-shrink-0" onClick={check}>Check</button>
      </div>

      {checked && result && (
        <div className={`p-4 rounded-lg border ${result.breached
          ? 'bg-cyber-red/10 border-cyber-red/30'
          : 'bg-cyber-green/10 border-cyber-green/30'
        }`}>
          {result.breached ? (
            <div className="space-y-1">
              <p className="text-cyber-red font-bold">⚠ Breached in {result.count} known incidents</p>
              <p className="text-cyber-muted text-sm">Change your password immediately and enable 2FA on this account.</p>
            </div>
          ) : (
            <p className="text-cyber-green font-bold">✓ No known breaches found</p>
          )}
        </div>
      )}
    </div>
  )
}

function PhishingDetector() {
  const [url, setUrl]    = useState('')
  const [result, setResult] = useState(null)

  const SUSPICIOUS = ['bit.ly', 'tinyurl', 'paypa1', 'amaz0n', 'login-secure', 'verify-account', 'free-prize']

  const analyse = () => {
    if (!url) return
    const lower = url.toLowerCase()
    const flags = SUSPICIOUS.filter(s => lower.includes(s))
    setResult({ suspicious: flags.length > 0, flags })
  }

  return (
    <div className="card space-y-4">
      <h2 className="font-bold text-cyber-text text-lg">🎣 URL Phishing Analyser</h2>
      <p className="text-cyber-muted text-sm">Paste a suspicious URL to check for common phishing indicators.</p>

      <div className="flex gap-2">
        <input className="input font-mono text-xs" type="url" placeholder="https://example.com/…"
          value={url} onChange={e => { setUrl(e.target.value); setResult(null) }} />
        <button className="btn-primary flex-shrink-0" onClick={analyse}>Analyse</button>
      </div>

      {result && (
        <div className={`p-4 rounded-lg border ${result.suspicious
          ? 'bg-cyber-red/10 border-cyber-red/30'
          : 'bg-cyber-green/10 border-cyber-green/30'
        }`}>
          {result.suspicious ? (
            <div className="space-y-2">
              <p className="text-cyber-red font-bold">⚠ Suspicious indicators found</p>
              <div className="flex flex-wrap gap-1">
                {result.flags.map(f => <span key={f} className="badge bg-cyber-red/20 text-cyber-red">{f}</span>)}
              </div>
              <p className="text-cyber-muted text-xs">Do not click this link or enter any credentials.</p>
            </div>
          ) : (
            <p className="text-cyber-green font-bold">✓ No obvious phishing patterns detected — still verify the domain manually</p>
          )}
        </div>
      )}
    </div>
  )
}

export default function Tools() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">🔧 Security Tools</h1>
      <PasswordChecker />
      <BreachChecker />
      <PhishingDetector />
    </div>
  )
}
