import { useMemo } from 'react'
import { useSelector } from 'react-redux'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, RadarChart, PolarGrid,
  PolarAngleAxis, Radar, Legend,
} from 'recharts'

const THREAT_DATA = [
  { month: 'Jan', phishing: 45, ransomware: 12, malware: 30 },
  { month: 'Feb', phishing: 52, ransomware: 18, malware: 28 },
  { month: 'Mar', phishing: 49, ransomware: 22, malware: 35 },
  { month: 'Apr', phishing: 70, ransomware: 15, malware: 40 },
  { month: 'May', phishing: 65, ransomware: 30, malware: 38 },
  { month: 'Jun', phishing: 80, ransomware: 28, malware: 42 },
]

const RADAR_DATA = [
  { subject: 'Phishing',      A: 90 },
  { subject: 'Passwords',     A: 75 },
  { subject: 'Malware',       A: 60 },
  { subject: 'Social Eng.',   A: 80 },
  { subject: 'Network',       A: 55 },
  { subject: 'Data Privacy',  A: 70 },
]

const tooltipStyle = {
  contentStyle: { background: '#21262D', border: '1px solid #30363D', borderRadius: 8 },
  labelStyle:   { color: '#C9D1D9' },
  itemStyle:    { color: '#00D4AA' },
}

export default function Dashboard() {
  const { user }    = useSelector(s => s.auth)
  const { history } = useSelector(s => s.quiz)
  const bookmarks   = useSelector(s => s.news.bookmarks)

  const chartData = useMemo(() =>
    history.map((h, i) => ({
      attempt: `#${history.length - i}`,
      score:   h.score,
      total:   h.total,
      pct:     Math.round((h.score / h.total) * 100),
    })).reverse()
  , [history])

  const avgScore = history.length
    ? Math.round(history.reduce((a, h) => a + (h.score / h.total) * 100, 0) / history.length)
    : 0

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">📊 Dashboard</h1>
        <span className="badge bg-cyber-green/10 text-cyber-green">{user?.role?.toUpperCase()}</span>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: '🧠', label: 'Quizzes Taken', value: history.length },
          { icon: '🎯', label: 'Avg Score',      value: `${avgScore}%` },
          { icon: '🔖', label: 'Bookmarks',      value: bookmarks.length },
          { icon: '🏆', label: 'Best Score',     value: history.length ? `${Math.max(...history.map(h => Math.round((h.score/h.total)*100)))}%` : 'N/A' },
        ].map(s => (
          <div key={s.label} className="card text-center">
            <div className="text-3xl mb-1">{s.icon}</div>
            <div className="text-2xl font-bold text-cyber-green font-mono">{s.value}</div>
            <div className="text-cyber-muted text-xs">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Quiz score history chart */}
      <div className="card space-y-3">
        <h2 className="font-semibold text-cyber-text">📈 Quiz Score History</h2>
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#30363D" />
              <XAxis dataKey="attempt" stroke="#8B949E" tick={{ fontSize: 11 }} />
              <YAxis domain={[0, 100]} stroke="#8B949E" tick={{ fontSize: 11 }} unit="%" />
              <Tooltip {...tooltipStyle} formatter={v => [`${v}%`, 'Score']} />
              <Line type="monotone" dataKey="pct" stroke="#00D4AA" strokeWidth={2}
                dot={{ fill: '#00D4AA', r: 4 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="text-center py-10 text-cyber-muted">
            <p>Take the quiz to see your score history here.</p>
          </div>
        )}
      </div>

      {/* Threat Landscape chart */}
      <div className="card space-y-3">
        <h2 className="font-semibold text-cyber-text">🌐 Global Threat Trend (2026)</h2>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={THREAT_DATA}>
            <CartesianGrid strokeDasharray="3 3" stroke="#30363D" />
            <XAxis dataKey="month" stroke="#8B949E" tick={{ fontSize: 11 }} />
            <YAxis stroke="#8B949E" tick={{ fontSize: 11 }} />
            <Tooltip {...tooltipStyle} />
            <Legend wrapperStyle={{ fontSize: 11, color: '#8B949E' }} />
            <Bar dataKey="phishing"   fill="#FF6B6B" radius={[4,4,0,0]} />
            <Bar dataKey="ransomware" fill="#FF9F43" radius={[4,4,0,0]} />
            <Bar dataKey="malware"    fill="#58A6FF" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Radar: awareness coverage */}
      <div className="card space-y-3">
        <h2 className="font-semibold text-cyber-text">🎯 Awareness Coverage Radar</h2>
        <ResponsiveContainer width="100%" height={280}>
          <RadarChart data={RADAR_DATA}>
            <PolarGrid stroke="#30363D" />
            <PolarAngleAxis dataKey="subject" tick={{ fill: '#8B949E', fontSize: 11 }} />
            <Radar dataKey="A" stroke="#00D4AA" fill="#00D4AA" fillOpacity={0.2} />
          </RadarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
