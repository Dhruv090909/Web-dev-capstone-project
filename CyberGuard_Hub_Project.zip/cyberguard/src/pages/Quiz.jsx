import { useDispatch, useSelector } from 'react-redux'
import { startQuiz, answerQuestion, nextQuestion, prevQuestion, submitQuiz, resetQuiz, selectScore } from '../store/slices/quizSlice'

function ScoreGrade({ score, total }) {
  const pct   = Math.round((score / total) * 100)
  const grade = pct >= 90 ? { label: 'Expert',    icon: '🏆', color: 'text-cyber-green'  }
              : pct >= 70 ? { label: 'Proficient', icon: '🎯', color: 'text-cyber-blue'   }
              : pct >= 50 ? { label: 'Aware',      icon: '📚', color: 'text-yellow-400'   }
              :             { label: 'Beginner',   icon: '⚠️', color: 'text-cyber-red'    }

  return (
    <div className="text-center space-y-3">
      <div className="text-6xl">{grade.icon}</div>
      <div className={`text-4xl font-bold font-mono ${grade.color}`}>{score}/{total}</div>
      <div className={`text-xl font-semibold ${grade.color}`}>{grade.label} — {pct}%</div>
      <div className="w-full bg-cyber-border rounded-full h-3 overflow-hidden">
        <div className="h-3 rounded-full bg-cyber-green transition-all duration-700"
          style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

export default function Quiz() {
  const dispatch  = useDispatch()
  const { questions, current, answers, submitted, started, history } = useSelector(s => s.quiz)
  const score     = useSelector(selectScore)
  const q         = questions[current]

  // ── Not started ─────────────────────────────────────────────────────────────
  if (!started) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="card text-center space-y-4 glow-green">
          <div className="text-6xl">🧠</div>
          <h1 className="text-2xl font-bold">Cybersecurity Awareness Quiz</h1>
          <p className="text-cyber-muted">Test your knowledge across phishing, passwords, malware, social engineering, and more.</p>
          <div className="grid grid-cols-3 gap-3 text-sm">
            {[['❓', '8 Questions', ''], ['⏱', 'No Time Limit', ''], ['🏆', 'Instant Score', '']].map(([icon, label]) => (
              <div key={label} className="card">
                <div className="text-2xl mb-1">{icon}</div>
                <div className="text-cyber-muted text-xs">{label}</div>
              </div>
            ))}
          </div>
          <button className="btn-primary w-full py-3" onClick={() => dispatch(startQuiz())}>
            Start Quiz →
          </button>
        </div>

        {history.length > 0 && (
          <div className="card space-y-3">
            <h2 className="font-semibold text-cyber-text">📈 Your History</h2>
            <div className="space-y-2">
              {history.slice(0, 5).map((h, i) => (
                <div key={i} className="flex items-center justify-between text-sm bg-cyber-mid rounded-lg px-3 py-2">
                  <span className="text-cyber-muted">{new Date(h.date).toLocaleDateString()}</span>
                  <span className={`font-bold font-mono ${h.score / h.total >= 0.7 ? 'text-cyber-green' : 'text-cyber-red'}`}>
                    {h.score}/{h.total}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  // ── Submitted — results ──────────────────────────────────────────────────────
  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="card space-y-5">
          <h2 className="font-bold text-xl text-center">Quiz Results</h2>
          <ScoreGrade score={score} total={questions.length} />
          <button className="btn-primary w-full" onClick={() => dispatch(resetQuiz())}>Try Again</button>
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold text-cyber-text">Review Answers</h3>
          {questions.map(q => {
            const chosen   = answers[q.id]
            const correct  = chosen === q.answer
            return (
              <div key={q.id} className={`card border-l-4 ${correct ? 'border-l-cyber-green' : 'border-l-cyber-red'}`}>
                <p className="font-medium text-sm mb-3">{q.question}</p>
                <div className="space-y-1.5">
                  {q.options.map((opt, i) => (
                    <div key={i} className={`text-xs px-3 py-2 rounded-lg font-mono ${
                      i === q.answer   ? 'bg-cyber-green/20 text-cyber-green' :
                      i === chosen     ? 'bg-cyber-red/20   text-cyber-red'   :
                                         'text-cyber-muted'
                    }`}>
                      {i === q.answer ? '✓ ' : i === chosen && !correct ? '✗ ' : '  '}{opt}
                    </div>
                  ))}
                </div>
                <p className="text-cyber-muted text-xs mt-3 italic">{q.explanation}</p>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  // ── Active quiz ──────────────────────────────────────────────────────────────
  const answered  = answers[q.id] !== undefined
  const isLast    = current === questions.length - 1
  const allDone   = questions.every(qq => answers[qq.id] !== undefined)

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* Progress */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs text-cyber-muted">
          <span>Question {current + 1} of {questions.length}</span>
          <span className="badge bg-cyber-green/10 text-cyber-green">{q.category}</span>
        </div>
        <div className="w-full bg-cyber-border rounded-full h-1.5">
          <div className="h-1.5 rounded-full bg-cyber-green transition-all duration-300"
            style={{ width: `${((current + 1) / questions.length) * 100}%` }} />
        </div>
      </div>

      {/* Question card */}
      <div className="card space-y-4">
        <p className="font-semibold text-cyber-text leading-relaxed">{q.question}</p>
        <div className="space-y-2.5">
          {q.options.map((opt, i) => (
            <button key={i}
              onClick={() => dispatch(answerQuestion({ id: q.id, index: i }))}
              className={`w-full text-left px-4 py-3 rounded-lg border text-sm transition-all duration-200 ${
                answers[q.id] === i
                  ? 'border-cyber-green bg-cyber-green/10 text-cyber-green'
                  : 'border-cyber-border text-cyber-muted hover:border-cyber-green/50 hover:text-cyber-text'
              }`}>
              <span className="font-mono text-cyber-muted mr-2">{String.fromCharCode(65 + i)}.</span>
              {opt}
            </button>
          ))}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between gap-3">
        <button className="btn-ghost" onClick={() => dispatch(prevQuestion())} disabled={current === 0}>
          ← Previous
        </button>
        <span className="text-cyber-muted text-xs">{Object.keys(answers).length}/{questions.length} answered</span>
        {isLast ? (
          <button
            className="btn-primary"
            disabled={!allDone}
            onClick={() => dispatch(submitQuiz())}
            title={!allDone ? 'Answer all questions first' : ''}
          >
            Submit Quiz ✓
          </button>
        ) : (
          <button className="btn-primary" onClick={() => dispatch(nextQuestion())} disabled={!answered}>
            Next →
          </button>
        )}
      </div>
    </div>
  )
}
