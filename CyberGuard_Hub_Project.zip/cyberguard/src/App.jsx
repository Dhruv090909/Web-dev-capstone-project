import { lazy, Suspense, useEffect } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { Navbar }         from './components/layout/Navbar'
import { Sidebar }        from './components/layout/Sidebar'
import { Toast }          from './components/common/Toast'
import { ErrorBoundary }  from './components/common/ErrorBoundary'
import { ProtectedRoute } from './router/ProtectedRoute'
import Home   from './pages/Home'
import Login  from './pages/Login'

// Lazy-loaded pages
const News       = lazy(() => import('./pages/News'))
const Quiz       = lazy(() => import('./pages/Quiz'))
const Tools      = lazy(() => import('./pages/Tools'))
const Dashboard  = lazy(() => import('./pages/Dashboard'))
const Bookmarks  = lazy(() => import('./pages/Bookmarks'))
const Admin      = lazy(() => import('./pages/Admin'))

function PageLoader() {
  return (
    <div className="flex-1 flex items-center justify-center min-h-[60vh]">
      <div className="text-center">
        <div className="text-4xl mb-3 animate-pulse">🛡</div>
        <p className="text-cyber-muted font-mono text-sm">Loading...</p>
      </div>
    </div>
  )
}

export default function App() {
  const darkMode = useSelector(s => s.ui.darkMode)

  // Apply dark class to html element
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode)
  }, [darkMode])

  return (
    <BrowserRouter>
      <div className={`min-h-screen flex flex-col bg-cyber-dark text-cyber-text`}>
        <Navbar />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar />
          <main className="flex-1 overflow-y-auto p-4 md:p-6">
            <ErrorBoundary>
              <Suspense fallback={<PageLoader />}>
                <Routes>
                  <Route path="/"          element={<Home />} />
                  <Route path="/login"     element={<Login />} />
                  <Route path="/news"      element={<News />} />
                  <Route path="/quiz"      element={<Quiz />} />
                  <Route path="/tools"     element={<Tools />} />
                  <Route path="/bookmarks" element={<Bookmarks />} />
                  <Route path="/dashboard" element={
                    <ProtectedRoute><Dashboard /></ProtectedRoute>
                  } />
                  <Route path="/admin" element={
                    <ProtectedRoute adminOnly><Admin /></ProtectedRoute>
                  } />
                  <Route path="*" element={
                    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
                      <div className="text-6xl mb-4">🔍</div>
                      <h2 className="text-2xl font-bold text-cyber-red mb-2">404 — Page Not Found</h2>
                      <p className="text-cyber-muted">This route does not exist in our system.</p>
                    </div>
                  } />
                </Routes>
              </Suspense>
            </ErrorBoundary>
          </main>
        </div>
        <Toast />
      </div>
    </BrowserRouter>
  )
}
