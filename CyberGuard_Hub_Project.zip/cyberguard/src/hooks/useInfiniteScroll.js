import { useEffect, useRef } from 'react'

/**
 * Calls `callback` when the sentinel element scrolls into view.
 * Attach `sentinelRef` to a div at the bottom of your list.
 */
export function useInfiniteScroll(callback, enabled = true) {
  const sentinelRef = useRef(null)

  useEffect(() => {
    if (!enabled) return
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) callback() },
      { threshold: 0.1 }
    )
    if (sentinelRef.current) observer.observe(sentinelRef.current)
    return () => observer.disconnect()
  }, [callback, enabled])

  return sentinelRef
}
